console.log('Welcome to the Console!');

$(document).ready(function () {
    // Scroll the whole document
    $.localScroll({
        target: 'body',
        duration: 200
    });

});